package br.org.cesar.weatherapp

import android.provider.SyncStateContract

object Constants {

    const val PREF_NAME = "weather"
    const val PREF_TEMP_C = "temp_c"
    const val PREF_LANG_EN = "lang_en"

}